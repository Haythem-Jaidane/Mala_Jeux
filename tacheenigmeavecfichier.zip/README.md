# jeux-2D
PS: Dans le test du code le temps de réponse est limité ,chaque 10 secondes une nouvelle énigme s'affichera.
La réponse peut-etre par OUI(appuyez sur "a") ou par NON(appuyez sur "z").
Une fois la réponse est donnée "Bravo!!" ou "Perdu" s'affichera et pour en finir et fermer la fenetre appuyez sur "SDL_QUIT".
